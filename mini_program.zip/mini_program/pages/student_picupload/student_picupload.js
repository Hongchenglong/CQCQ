Page({
  goto1: function () {
    wx.navigateTo({
      url: '/pages/uploadphoto/uploadphoto',
    })
  },

  goto2: function () {
    wx.navigateTo({
      url: '/pages/student_check/student_check',
    })
  }
})